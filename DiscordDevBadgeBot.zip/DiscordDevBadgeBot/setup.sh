#!/bin/bash

# Discord Bot Setup Script for Ubuntu Linux
# This script automates the installation and setup process

set -e  # Exit on any error

echo "🤖 Discord Bot Setup Script"
echo "=========================="

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    print_error "Please do not run this script as root!"
    print_error "Run it as a regular user with sudo privileges."
    exit 1
fi

# Update system packages
print_status "Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install Python 3 and pip if not already installed
print_status "Installing Python 3 and pip..."
sudo apt install -y python3 python3-pip python3-venv python3-dev

# Install system dependencies
print_status "Installing system dependencies..."
sudo apt install -y git curl wget build-essential

# Create bot directory
BOT_DIR="$HOME/discord-bot"
print_status "Creating bot directory at $BOT_DIR..."
mkdir -p "$BOT_DIR"

# Create Python virtual environment
print_status "Creating Python virtual environment..."
cd "$BOT_DIR"
python3 -m venv venv

# Activate virtual environment
print_status "Activating virtual environment..."
source venv/bin/activate

# Install Python dependencies
print_status "Installing Python dependencies..."
pip install --upgrade pip
pip install discord.py python-dotenv psutil

# Create .env file from example
if [ ! -f ".env" ]; then
    print_status "Creating .env file..."
    cp .env.example .env
    print_warning "Please edit .env file and add your Discord bot token!"
fi

# Create systemd service file
print_status "Creating systemd service..."
SERVICE_FILE="/etc/systemd/system/discord-bot.service"

sudo tee "$SERVICE_FILE" > /dev/null << EOL
[Unit]
Description=Discord Bot Service
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$BOT_DIR
Environment=PATH=$BOT_DIR/venv/bin
ExecStart=$BOT_DIR/venv/bin/python main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOL

# Reload systemd and enable service
print_status "Configuring systemd service..."
sudo systemctl daemon-reload
sudo systemctl enable discord-bot.service

# Create log directory
print_status "Creating log directory..."
mkdir -p "$BOT_DIR/logs"

# Set up log rotation
print_status "Setting up log rotation..."
sudo tee "/etc/logrotate.d/discord-bot" > /dev/null << EOL
$BOT_DIR/bot.log {
    daily
    missingok
    rotate 7
    compress
    delaycompress
    notifempty
    copytruncate
}
EOL

# Create helper scripts
print_status "Creating helper scripts..."

# Start script
cat > start.sh << 'EOL'
#!/bin/bash
echo "Starting Discord Bot..."
sudo systemctl start discord-bot.service
sudo systemctl status discord-bot.service
EOL

# Stop script
cat > stop.sh << 'EOL'
#!/bin/bash
echo "Stopping Discord Bot..."
sudo systemctl stop discord-bot.service
EOL

# Status script
cat > status.sh << 'EOL'
#!/bin/bash
echo "Discord Bot Status:"
sudo systemctl status discord-bot.service
echo ""
echo "Recent logs:"
tail -n 20 bot.log
EOL

# Logs script
cat > logs.sh << 'EOL'
#!/bin/bash
echo "Discord Bot Logs (press Ctrl+C to exit):"
tail -f bot.log
EOL

# Update script
cat > update.sh << 'EOL'
#!/bin/bash
echo "Updating Discord Bot..."
source venv/bin/activate
pip install --upgrade discord.py python-dotenv psutil
sudo systemctl restart discord-bot.service
echo "Bot updated and restarted!"
EOL

# Make scripts executable
chmod +x *.sh

print_success "Discord Bot setup completed!"
print_status "Setup Summary:"
echo "  - Bot directory: $BOT_DIR"
echo "  - Virtual environment: $BOT_DIR/venv"
echo "  - Service name: discord-bot.service"
echo "  - Configuration file: $BOT_DIR/.env"

print_warning "Next steps:"
echo "1. Edit the .env file and add your Discord bot token:"
echo "   nano .env"
echo ""
echo "2. Test the bot manually:"
echo "   cd $BOT_DIR && source venv/bin/activate && python main.py"
echo ""
echo "3. Start the bot service:"
echo "   ./start.sh"
echo ""
echo "4. Check bot status:"
echo "   ./status.sh"
echo ""
echo "5. View live logs:"
echo "   ./logs.sh"

print_success "Setup complete! Remember to add your bot token to the .env file."
