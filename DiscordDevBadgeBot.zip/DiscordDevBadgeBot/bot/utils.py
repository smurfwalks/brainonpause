"""
Discord Bot Utilities
Contains utility functions and helpers for the bot.
"""

import time
from datetime import datetime, timedelta
import discord
from discord.ext import commands

# Bot start time for uptime calculation
bot_start_time = time.time()

def format_uptime(uptime_seconds: float) -> str:
    """Format uptime in a human-readable format."""
    uptime = timedelta(seconds=int(uptime_seconds))
    
    days = uptime.days
    hours, remainder = divmod(uptime.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds or not parts:
        parts.append(f"{seconds}s")
    
    return " ".join(parts)

def get_bot_stats(bot: commands.Bot) -> dict:
    """Get comprehensive bot statistics."""
    current_time = time.time()
    uptime = current_time - bot_start_time
    
    # Count statistics
    guild_count = len(bot.guilds)
    user_count = len(set(bot.get_all_members()))
    channel_count = sum(len(guild.channels) for guild in bot.guilds)
    
    return {
        'guilds': guild_count,
        'users': user_count,
        'channels': channel_count,
        'uptime': uptime,
        'start_time': bot_start_time
    }

def create_error_embed(title: str, description: str, color: discord.Color = discord.Color.red()) -> discord.Embed:
    """Create a standardized error embed."""
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.utcnow()
    )
    return embed

def create_success_embed(title: str, description: str, color: discord.Color = discord.Color.green()) -> discord.Embed:
    """Create a standardized success embed."""
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.utcnow()
    )
    return embed

def format_permissions(permissions: discord.Permissions) -> list:
    """Format permissions into a readable list."""
    permission_list = []
    
    # Key permissions to display
    key_perms = [
        ('administrator', 'Administrator'),
        ('manage_guild', 'Manage Server'),
        ('manage_roles', 'Manage Roles'),
        ('manage_channels', 'Manage Channels'),
        ('kick_members', 'Kick Members'),
        ('ban_members', 'Ban Members'),
        ('manage_messages', 'Manage Messages'),
        ('send_messages', 'Send Messages'),
        ('read_messages', 'Read Messages'),
        ('connect', 'Connect to Voice'),
        ('speak', 'Speak in Voice')
    ]
    
    for perm_name, display_name in key_perms:
        if getattr(permissions, perm_name, False):
            permission_list.append(display_name)
    
    return permission_list

def truncate_text(text: str, max_length: int = 1024) -> str:
    """Truncate text to fit Discord embed limits."""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."

def get_member_status_emoji(status: discord.Status) -> str:
    """Get emoji representation of member status."""
    status_emojis = {
        discord.Status.online: "🟢",
        discord.Status.idle: "🟡",
        discord.Status.dnd: "🔴",
        discord.Status.offline: "⚫"
    }
    return status_emojis.get(status, "❓")

def format_time_since(timestamp: datetime) -> str:
    """Format time since a given timestamp."""
    now = datetime.utcnow()
    if timestamp.tzinfo is None:
        timestamp = timestamp.replace(tzinfo=None)
        now = now.replace(tzinfo=None)
    
    time_diff = now - timestamp
    
    if time_diff.days > 0:
        return f"{time_diff.days} days ago"
    elif time_diff.seconds > 3600:
        hours = time_diff.seconds // 3600
        return f"{hours} hours ago"
    elif time_diff.seconds > 60:
        minutes = time_diff.seconds // 60
        return f"{minutes} minutes ago"
    else:
        return "Just now"
