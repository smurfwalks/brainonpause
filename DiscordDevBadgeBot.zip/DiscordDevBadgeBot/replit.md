# Discord Bot for Developer Badge

## Overview

This is a Python-based Discord bot designed to help users qualify for the Discord Developer Badge. The bot features modern slash commands, comprehensive server and user information tools, and interactive help systems. It's built using the discord.py library with a modular architecture that separates commands, events, and utilities into distinct modules.

## User Preferences

Preferred communication style: Simple, everyday language.
Language preference: Russian (Русский язык)

## System Architecture

The bot follows a modular monolithic architecture with clear separation of concerns:

**Core Structure:**
- `main.py`: Entry point and bot initialization
- `bot/`: Core bot package containing all functionality
- `bot/commands.py`: Slash command definitions and handlers
- `bot/events.py`: Discord event handlers (guild join, errors, etc.)
- `bot/utils.py`: Utility functions and helper methods

**Bot Framework:**
- Built on discord.py with commands extension
- Uses Discord's modern slash command system
- Implements custom Bot class extending commands.Bot

## Key Components

### Bot Class (main.py)
- Custom DiscordBot class extending commands.Bot
- Configures intents for message content, guilds, and members
- Sets up logging to both file and console
- Disables default help command in favor of custom implementation

### Command System (bot/commands.py)
- Implements slash commands using Discord's app_commands
- Commands include:
  - `/ping`: Latency and response time checking
  - `/bot`: Bot statistics and system information
  - `/server`: Server information and statistics
  - `/user`: User profile and server-specific data
  - `/help`: Interactive help system
- Uses rich embeds for all command responses
- Includes error handling and cooldown mechanisms

### Event Handling (bot/events.py)
- Handles bot lifecycle events
- Guild join events with welcome messages
- Error handling for command failures
- Automatic channel detection for bot communications

### Utilities (bot/utils.py)
- Uptime calculation and formatting
- Bot statistics aggregation
- Helper functions for data formatting
- Performance monitoring utilities

## Data Flow

1. **Bot Initialization**: Main.py loads environment variables, configures logging, and initializes the custom bot class
2. **Command Processing**: Slash commands are processed through the app_commands tree
3. **Event Handling**: Discord events trigger appropriate handlers in events.py
4. **Data Aggregation**: Utils.py provides centralized data collection and formatting
5. **Response Generation**: Rich embeds are created and sent back to Discord

## External Dependencies

### Core Dependencies
- `discord.py`: Primary Discord API wrapper
- `python-dotenv`: Environment variable management
- `psutil`: System information gathering
- `asyncio`: Asynchronous operation handling

### System Requirements
- Python 3.8+
- Ubuntu Linux (18.04, 20.04, 22.04+)
- Internet connection for Discord API access
- Discord Bot Token (from Discord Developer Portal)

### Discord Permissions
- Send Messages
- Use Slash Commands
- View Channels
- Read Message History
- Embed Links

## Deployment Strategy

### Environment Setup
- Uses `.env` file for sensitive configuration (bot token)
- Includes `setup.sh` script for automated installation
- Logging configured for both development and production

### Bot Configuration
- Intents properly configured for required permissions
- Slash commands registered globally
- Error handling for production stability
- File logging for debugging and monitoring

### Security Considerations
- Bot token stored in environment variables
- No hardcoded secrets in source code
- Proper intent configuration to minimize permissions
- Rate limiting through command cooldowns

The architecture prioritizes modularity, maintainability, and Discord best practices while keeping the codebase simple and focused on the core functionality needed for Developer Badge qualification.