#!/usr/bin/env python3
"""
Discord Bot for Developer Badge Qualification
Main entry point for the Discord bot application.
"""

import os
import logging
import asyncio
from dotenv import load_dotenv
import discord
from discord.ext import commands

from bot.commands import setup_commands
from bot.events import setup_events

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

class DiscordBot(commands.Bot):
    """Custom Discord Bot class with enhanced functionality."""
    
    def __init__(self):
        # Bot intents configuration
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None,  # We'll create a custom help command
            case_insensitive=True
        )
        
    async def setup_hook(self):
        """Called when the bot is starting up."""
        logger.info("Setting up bot...")
        
        # Setup commands and events
        await setup_commands(self)
        setup_events(self)
        
        # Sync slash commands
        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} command(s)")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")
    
    async def on_ready(self):
        """Called when the bot is ready."""
        logger.info(f'{self.user} has connected to Discord!')
        logger.info(f'Bot is in {len(self.guilds)} guilds')
        
        # Set bot activity
        activity = discord.Activity(
            type=discord.ActivityType.watching,
            name="for /help commands"
        )
        await self.change_presence(
            status=discord.Status.online,
            activity=activity
        )

def main():
    """Main function to run the bot."""
    # Get bot token from environment
    token = os.getenv('DISCORD_BOT_TOKEN')
    
    if not token:
        logger.error("DISCORD_BOT_TOKEN environment variable is not set!")
        logger.error("Please create a .env file with your bot token.")
        return
    
    # Create and run bot
    bot = DiscordBot()
    
    try:
        bot.run(token)
    except discord.LoginFailure:
        logger.error("Invalid bot token provided!")
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested by user")
    except Exception as e:
        logger.error(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
