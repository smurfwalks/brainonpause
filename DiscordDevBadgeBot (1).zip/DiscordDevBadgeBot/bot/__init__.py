"""
Discord Bot Package
Contains all bot-related modules and functionality.
"""

__version__ = "1.0.0"
__author__ = "Discord Developer"
