"""
Discord Bot Commands
Contains all slash commands and command groups for the bot.
"""

import discord
from discord.ext import commands
from discord import app_commands
import time
import platform
import psutil
import logging
from datetime import datetime
from .utils import format_uptime, get_bot_stats

logger = logging.getLogger(__name__)

async def setup_commands(bot: commands.Bot):
    """Setup all bot commands."""
    
    @bot.tree.command(name="ping", description="Check bot latency and response time")
    async def ping(interaction: discord.Interaction):
        """Ping command to check bot responsiveness."""
        start_time = time.time()
        
        embed = discord.Embed(
            title="🏓 Pong!",
            color=discord.Color.green(),
            timestamp=datetime.utcnow()
        )
        
        # Calculate latencies
        api_latency = round(bot.latency * 1000, 2)
        
        embed.add_field(
            name="API Latency",
            value=f"`{api_latency}ms`",
            inline=True
        )
        
        await interaction.response.send_message(embed=embed)
        
        # Calculate response time
        end_time = time.time()
        response_time = round((end_time - start_time) * 1000, 2)
        
        embed.add_field(
            name="Response Time",
            value=f"`{response_time}ms`",
            inline=True
        )
        
        await interaction.edit_original_response(embed=embed)
        logger.info(f"Ping command used by {interaction.user}")
    
    @bot.tree.command(name="info", description="Display bot information and statistics")
    async def info(interaction: discord.Interaction):
        """Display comprehensive bot information."""
        stats = get_bot_stats(bot)
        
        embed = discord.Embed(
            title="🤖 Bot Information",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        
        if bot.user and bot.user.avatar:
            embed.set_thumbnail(url=bot.user.avatar.url)
        
        # Bot details
        if bot.user:
            embed.add_field(
                name="Bot Details",
                value=f"**Name:** {bot.user.name}\n"
                      f"**ID:** {bot.user.id}\n"
                      f"**Created:** <t:{int(bot.user.created_at.timestamp())}:R>",
                inline=False
            )
        
        # Statistics
        embed.add_field(
            name="Statistics",
            value=f"**Guilds:** {stats['guilds']}\n"
                  f"**Users:** {stats['users']}\n"
                  f"**Channels:** {stats['channels']}",
            inline=True
        )
        
        # System info
        embed.add_field(
            name="System",
            value=f"**Python:** {platform.python_version()}\n"
                  f"**Discord.py:** {discord.__version__}\n"
                  f"**Platform:** {platform.system()}",
            inline=True
        )
        
        # Performance
        memory_usage = psutil.Process().memory_info().rss / 1024 / 1024
        embed.add_field(
            name="Performance",
            value=f"**Memory:** {memory_usage:.1f} MB\n"
                  f"**Uptime:** {format_uptime(stats['uptime'])}\n"
                  f"**Latency:** {round(bot.latency * 1000, 2)}ms",
            inline=True
        )
        
        embed.set_footer(text="Discord Developer Bot • Made with discord.py")
        
        await interaction.response.send_message(embed=embed)
        logger.info(f"Info command used by {interaction.user}")
    
    @bot.tree.command(name="server", description="Display server information")
    async def server(interaction: discord.Interaction):
        """Display server information."""
        guild = interaction.guild
        
        if not guild:
            await interaction.response.send_message(
                "❌ This command can only be used in a server!",
                ephemeral=True
            )
            return
        
        embed = discord.Embed(
            title=f"🏰 {guild.name}",
            color=discord.Color.purple(),
            timestamp=datetime.utcnow()
        )
        
        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        
        # Server details
        embed.add_field(
            name="Server Details",
            value=f"**Owner:** {guild.owner.mention if guild.owner else 'Unknown'}\n"
                  f"**Created:** <t:{int(guild.created_at.timestamp())}:R>\n"
                  f"**ID:** {guild.id}",
            inline=False
        )
        
        # Statistics
        embed.add_field(
            name="Members",
            value=f"**Total:** {guild.member_count}\n"
                  f"**Humans:** {len([m for m in guild.members if not m.bot])}\n"
                  f"**Bots:** {len([m for m in guild.members if m.bot])}",
            inline=True
        )
        
        embed.add_field(
            name="Channels",
            value=f"**Text:** {len(guild.text_channels)}\n"
                  f"**Voice:** {len(guild.voice_channels)}\n"
                  f"**Categories:** {len(guild.categories)}",
            inline=True
        )
        
        embed.add_field(
            name="Other",
            value=f"**Roles:** {len(guild.roles)}\n"
                  f"**Emojis:** {len(guild.emojis)}\n"
                  f"**Boost Level:** {guild.premium_tier}",
            inline=True
        )
        
        # Features
        if guild.features:
            features = [feature.replace('_', ' ').title() for feature in guild.features[:5]]
            embed.add_field(
                name="Features",
                value='\n'.join(f"• {feature}" for feature in features),
                inline=False
            )
        
        await interaction.response.send_message(embed=embed)
        logger.info(f"Server command used by {interaction.user} in {guild.name}")
    
    @bot.tree.command(name="user", description="Display user information")
    @app_commands.describe(member="The user to get information about")
    async def user(interaction: discord.Interaction, member: discord.Member | None = None):
        """Display user information."""
        if member is None:
            if isinstance(interaction.user, discord.Member):
                target = interaction.user
            else:
                await interaction.response.send_message(
                    "❌ This command can only be used in a server!",
                    ephemeral=True
                )
                return
        else:
            target = member
        
        embed = discord.Embed(
            title=f"👤 {target.display_name}",
            color=target.color if target.color != discord.Color.default() else discord.Color.orange(),
            timestamp=datetime.utcnow()
        )
        
        if target.avatar:
            embed.set_thumbnail(url=target.avatar.url)
        
        # User details
        embed.add_field(
            name="User Details",
            value=f"**Username:** {target.name}\n"
                  f"**ID:** {target.id}\n"
                  f"**Created:** <t:{int(target.created_at.timestamp())}:R>",
            inline=False
        )
        
        # Server-specific info
        if isinstance(target, discord.Member) and target.joined_at:
            embed.add_field(
                name="Server Info",
                value=f"**Joined:** <t:{int(target.joined_at.timestamp())}:R>\n"
                      f"**Nickname:** {target.nick or 'None'}\n"
                      f"**Top Role:** {target.top_role.mention}",
                inline=True
            )
            
            # Roles
            if len(target.roles) > 1:
                roles = [role.mention for role in target.roles[1:]]  # Exclude @everyone
                if len(roles) > 10:
                    roles = roles[:10] + [f"... and {len(roles) - 10} more"]
                
                embed.add_field(
                    name=f"Roles ({len(target.roles) - 1})",
                    value=" ".join(roles) if roles else "None",
                    inline=False
                )
        
        # Status and activity
        status_emoji = {
            discord.Status.online: "🟢",
            discord.Status.idle: "🟡",
            discord.Status.dnd: "🔴",
            discord.Status.offline: "⚫"
        }
        
        embed.add_field(
            name="Status",
            value=f"{status_emoji.get(target.status, '❓')} {target.status.name.title()}",
            inline=True
        )
        
        await interaction.response.send_message(embed=embed)
        logger.info(f"User command used by {interaction.user} for {target}")
    
    @bot.tree.command(name="help", description="Display available commands and bot help")
    async def help_command(interaction: discord.Interaction):
        """Custom help command."""
        embed = discord.Embed(
            title="🆘 Bot Commands Help",
            description="Here are all available commands for this bot:",
            color=discord.Color.blue(),
            timestamp=datetime.utcnow()
        )
        
        commands_info = [
            ("🏓 `/ping`", "Check bot latency and response time"),
            ("🤖 `/info`", "Display bot information and statistics"),
            ("🏰 `/server`", "Display current server information"),
            ("👤 `/user [member]`", "Display user information (yourself or mentioned user)"),
            ("🆘 `/help`", "Show this help message"),
        ]
        
        for name, description in commands_info:
            embed.add_field(
                name=name,
                value=description,
                inline=False
            )
        
        embed.add_field(
            name="📝 Notes",
            value="• All commands are slash commands (start with `/`)\n"
                  "• Optional parameters are shown in `[brackets]`\n"
                  "• Some commands may be server-specific",
            inline=False
        )
        
        embed.set_footer(text="Discord Developer Bot • Use slash commands for best experience")
        
        await interaction.response.send_message(embed=embed)
        logger.info(f"Help command used by {interaction.user}")
    
    # Cooldowns removed to fix slash command compatibility issues
    
    logger.info("All commands have been set up successfully")
