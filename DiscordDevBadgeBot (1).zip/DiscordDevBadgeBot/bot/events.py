"""
Discord Bot Events
Contains event handlers for the Discord bot.
"""

import discord
from discord.ext import commands
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def setup_events(bot: commands.Bot):
    """Setup all bot event handlers."""
    
    @bot.event
    async def on_guild_join(guild: discord.Guild):
        """Called when the bot joins a new guild."""
        logger.info(f"Joined guild: {guild.name} (ID: {guild.id})")
        
        # Try to send a welcome message to the system channel or first text channel
        channel = guild.system_channel
        if not channel:
            # Find the first text channel the bot can send messages to
            for text_channel in guild.text_channels:
                if text_channel.permissions_for(guild.me).send_messages:
                    channel = text_channel
                    break
        
        if channel:
            embed = discord.Embed(
                title="👋 Hello there!",
                description="Thanks for adding me to your server!",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            
            embed.add_field(
                name="Getting Started",
                value="Use `/help` to see all available commands!\n"
                      "All commands are slash commands - just type `/` to see them.",
                inline=False
            )
            
            embed.add_field(
                name="Features",
                value="• Server and user information\n"
                      "• Bot statistics and health\n"
                      "• Interactive slash commands\n"
                      "• And more!",
                inline=False
            )
            
            embed.set_footer(text="Discord Developer Bot")
            
            try:
                await channel.send(embed=embed)
            except discord.Forbidden:
                logger.warning(f"Could not send welcome message in {guild.name} - no permissions")
    
    @bot.event
    async def on_guild_remove(guild: discord.Guild):
        """Called when the bot is removed from a guild."""
        logger.info(f"Left guild: {guild.name} (ID: {guild.id})")
    
    @bot.event
    async def on_command_error(ctx: commands.Context, error: commands.CommandError):
        """Handle command errors."""
        if isinstance(error, commands.CommandOnCooldown):
            embed = discord.Embed(
                title="⏱️ Cooldown",
                description=f"Please wait {error.retry_after:.1f} seconds before using this command again.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed, ephemeral=True)
        
        elif isinstance(error, commands.MissingPermissions):
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="You don't have permission to use this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
        
        elif isinstance(error, commands.BotMissingPermissions):
            embed = discord.Embed(
                title="❌ Bot Missing Permissions",
                description="I don't have the required permissions to execute this command.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed, ephemeral=True)
        
        else:
            logger.error(f"Unhandled command error: {error}")
    
    @bot.event
    async def on_app_command_error(interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
        """Handle application command errors."""
        if isinstance(error, discord.app_commands.CommandOnCooldown):
            embed = discord.Embed(
                title="⏱️ Cooldown",
                description=f"Please wait {error.retry_after:.1f} seconds before using this command again.",
                color=discord.Color.orange()
            )
            
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        
        elif isinstance(error, discord.app_commands.MissingPermissions):
            embed = discord.Embed(
                title="❌ Missing Permissions",
                description="You don't have permission to use this command.",
                color=discord.Color.red()
            )
            
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        
        elif isinstance(error, discord.app_commands.BotMissingPermissions):
            embed = discord.Embed(
                title="❌ Bot Missing Permissions",
                description="I don't have the required permissions to execute this command.",
                color=discord.Color.red()
            )
            
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
        
        else:
            logger.error(f"Unhandled app command error: {error}")
            
            embed = discord.Embed(
                title="❌ An Error Occurred",
                description="An unexpected error occurred while processing your command.",
                color=discord.Color.red()
            )
            
            if interaction.response.is_done():
                await interaction.followup.send(embed=embed, ephemeral=True)
            else:
                await interaction.response.send_message(embed=embed, ephemeral=True)
    
    @bot.event
    async def on_error(event: str, *args, **kwargs):
        """Handle general bot errors."""
        logger.error(f"Error in event {event}: {args}, {kwargs}")
    
    logger.info("All event handlers have been set up successfully")
