# Discord Bot for Developer Badge

A Python Discord bot with interactive slash commands designed to help you qualify for the Discord Developer Badge. The bot includes comprehensive features like server information, user profiles, bot statistics, and proper error handling.

## Features

- 🏓 **Ping Command** - Check bot latency and response time
- 🤖 **Bot Info** - Display comprehensive bot statistics and system information
- 🏰 **Server Info** - Show detailed server information and statistics
- 👤 **User Info** - Display user profiles and server-specific information
- 🆘 **Help Command** - Interactive help system with all available commands
- ⚡ **Slash Commands** - Modern Discord slash command integration
- 🔒 **Error Handling** - Comprehensive error handling and user feedback
- 📊 **Logging** - Detailed logging system for monitoring and debugging
- 🛡️ **Cooldowns** - Command rate limiting to prevent spam
- 🎭 **Rich Embeds** - Beautiful, interactive message embeds

## Requirements

- Python 3.8 or higher
- Ubuntu Linux (18.04, 20.04, 22.04 or newer)
- Discord Bot Token
- Internet connection

## Quick Setup Guide

### 1. Create Discord Application

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Click "New Application" and give it a name
3. Go to "Bot" section and click "Add Bot"
4. Copy the bot token (keep it secret!)
5. Enable "Message Content Intent" if needed
6. Generate invite link with appropriate permissions

### 2. Server Installation

```bash
# Clone or download the bot files
mkdir discord-bot && cd discord-bot

# Make setup script executable and run it
chmod +x setup.sh
./setup.sh
