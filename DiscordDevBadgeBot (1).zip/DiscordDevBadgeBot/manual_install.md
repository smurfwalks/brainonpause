# Ручная установка Discord бота на Ubuntu

## 1. Установка Python зависимостей (без sudo)

```bash
# Установим зависимости через pip для пользователя
pip3 install --user discord.py python-dotenv psutil

# Или если pip3 не найден:
python3 -m pip install --user discord.py python-dotenv psutil
```

## 2. Создание .env файла

```bash
# Создаем файл конфигурации
cp .env.example .env

# Редактируем и добавляем ваш токен
nano .env
```

В файле .env замените:
```
DISCORD_BOT_TOKEN=ваш_настоящий_токен_здесь
```

## 3. Проверка работы бота

```bash
# Запуск бота для тестирования
python3 main.py
```

## 4. Создание простого systemd сервиса

```bash
# Создаем сервис файл
sudo nano /etc/systemd/system/discord-bot.service
```

Вставьте следующий текст (замените `smurfwalks` на ваше имя пользователя):

```ini
[Unit]
Description=Discord Bot Service
After=network.target

[Service]
Type=simple
User=smurfwalks
WorkingDirectory=/home/smurfwalks/discord-bot
ExecStart=/usr/bin/python3 main.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

## 5. Запуск сервиса

```bash
# Перезагружаем systemd
sudo systemctl daemon-reload

# Включаем автозапуск
sudo systemctl enable discord-bot.service

# Запускаем бота
sudo systemctl start discord-bot.service

# Проверяем статус
sudo systemctl status discord-bot.service
```

## Упрощенные команды управления

```bash
# Запуск
sudo systemctl start discord-bot

# Остановка  
sudo systemctl stop discord-bot

# Перезапуск
sudo systemctl restart discord-bot

# Статус
sudo systemctl status discord-bot

# Логи
sudo journalctl -u discord-bot -f
```

## Если systemd недоступен

Можно запустить бота в фоне с помощью screen:

```bash
# Установка screen
sudo apt install screen

# Запуск бота в фоне
screen -S discord-bot python3 main.py

# Отключение от сессии (Ctrl+A, затем D)
# Подключение обратно
screen -r discord-bot
```